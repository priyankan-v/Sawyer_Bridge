#!/usr/bin/env python3
"""Check this release against an active RoboStack environment before installation."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shlex
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--solve', action='store_true',
                        help='Also ask Conda to solve with --dry-run (network/cache access; no installation)')
    parser.add_argument('--with-sugarcoat', action='store_true',
                        help='Include the tested optional Sugarcoat build in the dry run/install command')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    manifest_path = root / 'release.json'
    if not manifest_path.exists():
        parser.error('Run the copy of this script inside the extracted release bundle')
    manifest = json.loads(manifest_path.read_text())
    failures = []
    warnings = []

    def report(level, label, detail):
        print(f'[{level}] {label}: {detail}', flush=True)
        if level == 'FAIL':
            failures.append(label)
        elif level == 'WARN':
            warnings.append(label)

    print(f"Sawyer bridge {manifest['version']} / {manifest['build']} prerequisite check")
    print('No robot connection or package installation is performed.\n')
    supported = platform.system() == 'Linux' and platform.machine() == 'x86_64'
    report('PASS' if supported else 'FAIL', 'Platform',
           f'{platform.system()} {platform.machine()} (requires Linux x86_64)')
    libc, libc_version = platform.libc_ver()
    try:
        glibc_ok = libc == 'glibc' and tuple(map(int, libc_version.split('.')[:2])) >= (2, 35)
    except ValueError:
        glibc_ok = False
    report('PASS' if glibc_ok else 'FAIL', 'C library',
           f'{libc or "unknown"} {libc_version} (requires glibc >=2.35)')
    artifact = root / manifest['artifact']
    intact = artifact.is_file() and hashlib.sha256(artifact.read_bytes()).hexdigest() == manifest['sha256']
    report('PASS' if intact else 'FAIL', 'Package checksum', str(artifact))

    active = os.environ.get('CONDA_PREFIX')
    if not active or not (Path(active) / 'conda-meta').is_dir():
        report('FAIL', 'Conda environment', 'Run conda activate ros_env, then rerun this script')
        return 1
    prefix = Path(active).resolve()
    report('PASS', 'Active environment', str(prefix))
    records = {}
    for file in (prefix / 'conda-meta').glob('*.json'):
        record = json.loads(file.read_text())
        records[record['name']] = record

    for name, expected in [('python', '3.12.'), ('libboost', '1.88.'),
                           ('numpy', '2.'), ('console_bridge', '1.0.')]:
        installed = records.get(name, {}).get('version', '')
        matches = installed.startswith(expected)
        report('PASS' if matches else 'WARN', name,
               f'{installed or "missing"}; required {expected}x'
               + ('' if matches else '; Conda must resolve this change (--solve)'))
    mutex = records.get('ros2-distro-mutex', {})
    humble = mutex.get('build', '').startswith('humble_')
    same_generation = humble and mutex.get('version', '').startswith('0.9.')
    report('PASS' if same_generation else 'WARN', 'RoboStack Humble generation',
           f"{mutex.get('version', 'missing')} {mutex.get('build', '')}; requires 0.9.x humble_*"
           + ('' if same_generation else '; review the Conda dry-run changes carefully'))
    if 'sawyer-ros2-bridge' in records:
        report('WARN', 'Legacy package', 'sawyer-ros2-bridge is installed; the new package conflicts with it')
    for spec in manifest['depends']:
        fields = spec.split()
        if len(fields) == 3 and fields[0].startswith('ros-humble-'):
            name, version, build = fields
            current = records.get(name, {})
            matches = current.get('version') == version and current.get('build') == build
            report('PASS' if matches else 'WARN', name,
                   f"installed {current.get('version', 'missing')} {current.get('build', '')}; "
                   f'required {version} {build}')

    for variable in ('PYTHONPATH', 'LD_LIBRARY_PATH', 'AMENT_PREFIX_PATH', 'CMAKE_PREFIX_PATH'):
        contaminated = [entry for entry in os.environ.get(variable, '').split(':')
                        if entry.startswith('/opt/ros/')]
        if contaminated:
            report('FAIL', variable, 'System ROS is sourced: ' + ':'.join(contaminated)
                   + '. Use a fresh terminal and activate only the Conda environment')
    probe = '''import json, sys
import rclpy
from sensor_msgs.msg import JointState
JointState.__class__.__import_type_support__()
print(json.dumps({'python': sys.version.split()[0], 'rclpy': rclpy.__file__}))
'''
    try:
        result = subprocess.run([str(prefix / 'bin/python'), '-I', '-c', probe],
                                capture_output=True, text=True, timeout=30)
        if result.returncode:
            detail = (result.stderr or result.stdout).strip().splitlines()
            report('WARN', 'Existing ROS 2 Python/type support',
                   (detail[-1] if detail else 'Import failed') + '; repair/resolve dependencies before use')
        else:
            info = json.loads(result.stdout)
            local = Path(info['rclpy']).resolve().is_relative_to(prefix)
            report('PASS' if local else 'FAIL', 'Existing ROS 2 Python/type support',
                   f"Python {info['python']}; rclpy from {info['rclpy']}")
    except (OSError, subprocess.TimeoutExpired, ValueError) as error:
        report('WARN', 'Existing ROS 2 Python/type support', str(error))

    free_gib = shutil.disk_usage(prefix).free / 1024**3
    report('PASS' if free_gib >= 2 else 'WARN', 'Free disk space',
           f'{free_gib:.1f} GiB; actual download/install size depends on the solver plan')
    conda = os.environ.get('CONDA_EXE') or shutil.which('conda')
    command = [conda or 'conda', 'install', '--prefix', str(prefix), '--override-channels',
               '-c', root.as_uri(), '-c', 'conda-forge', '-c', 'robostack-humble',
               f"sawyer_bridge={manifest['version']}={manifest['build']}"]
    if args.with_sugarcoat:
        command.extend(manifest['sugarcoat_specs'])
    if args.solve:
        if not conda:
            report('FAIL', 'Conda solver', 'Cannot locate Conda; activate its shell integration first')
        elif failures:
            report('WARN', 'Conda solver', 'Skipped until the failed platform/environment checks are fixed')
        else:
            print('\nRunning Conda --dry-run --json; this may fetch/cache channel metadata...', flush=True)
            try:
                result = subprocess.run(command + ['--dry-run', '--json'],
                                        capture_output=True, text=True, timeout=600)
                plan = json.loads(result.stdout)
                if result.returncode or not plan.get('success', False):
                    report('FAIL', 'Conda solver', plan.get('message', result.stderr or 'No compatible solution'))
                else:
                    report('PASS', 'Conda solver', 'A compatible transaction exists; nothing was installed')
                    actions = plan.get('actions', {})
                    for action, label in [('UNLINK', 'REMOVE/REPLACE'), ('LINK', 'INSTALL')]:
                        for record in actions.get(action, []):
                            print(f"  {label}: {record['name']} {record['version']} {record.get('build_string', record.get('build', ''))}")
            except (OSError, subprocess.TimeoutExpired, ValueError) as error:
                report('FAIL', 'Conda solver', f'Could not verify the transaction: {error}')

    print('\nInstall command (review proposed dependency changes before accepting):')
    print(shlex.join(command))
    print('\nThen: source "$CONDA_PREFIX/local_setup.bash"')
    print('      ros2 run sawyer_bridge check')
    print(f'\nResult: {len(failures)} failure(s), {len(warnings)} warning(s).')
    if not args.solve:
        print('Dependency resolution is not verified yet. Rerun with --solve for the authoritative Conda check.')
    if warnings:
        print('Warnings describe the current environment; inspect the dry-run plan for required changes.')
    print('This check does not validate robot networking or hardware.')
    return 1 if failures else 0


if __name__ == '__main__':
    sys.exit(main())
