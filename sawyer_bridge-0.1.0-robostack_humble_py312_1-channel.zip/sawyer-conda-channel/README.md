# Sawyer bridge 0.1.0 for RoboStack Humble

This bundle contains the prebuilt `sawyer_bridge-0.1.0-robostack_humble_py312_1.conda`, an indexed local Conda
channel, a prerequisite checker, and an optional Sugarcoat example. It contains
no bridge build sources. No sudo or compilation is needed on the destination PC.

## Before installing on another laptop

Extract the ZIP, open a fresh terminal inside `sawyer-conda-channel`, then run:

```bash
conda activate ros_env
sha256sum -c SHA256SUMS
python check_requirements.py --solve
```

The checker prints PASS/WARN/FAIL results, checks the package checksum and asks
Conda for a dry run. It does not install anything or contact the robot. The dry
run can access the network and update Conda's metadata cache. Review its listed
removals/replacements before accepting an installation. Warnings about versions
mean the current environment needs changes; the solver determines whether a
compatible transaction exists. Failed checks must be resolved first.

Requirements: Linux x86_64, glibc >=2.35 (tested on Ubuntu 22.04), Conda Python
3.12, NumPy 2, Boost 1.88 and RoboStack Humble generation 18 / mutex 0.9.
Other system Python versions do not matter. A newer RoboStack build is not
automatically ABI compatible. Internet access is needed for uncached dependencies.

## Install into the existing ros_env

From this extracted folder:

```bash
conda activate ros_env
conda install --override-channels \
  -c "file://$PWD" -c conda-forge -c robostack-humble \
  'sawyer_bridge=0.1.0=robostack_humble_py312_1'
source "$CONDA_PREFIX/local_setup.bash"
ros2 run sawyer_bridge check
ros2 launch sawyer_bridge bridge.launch.py --show-args
```

Use the channel command so Conda resolves dependencies. Direct installation of
the .conda file can bypass dependency resolution. Keep the whole channel folder
together. Conda may propose upgrades or downgrades; inspect the plan first.
Activate the environment and source local_setup.bash in each terminal.

## Optional Sugarcoat

Sugarcoat is not required by the bridge. To check and install the tested version:

```bash
python check_requirements.py --solve --with-sugarcoat
conda install --override-channels \
  -c "file://$PWD" -c conda-forge -c robostack-humble \
  'sawyer_bridge=0.1.0=robostack_humble_py312_1' \
  'ros-humble-automatika-ros-sugar=0.7.0=np2py312h3b5449b_18' msgpack-numpy
source "$CONDA_PREFIX/local_setup.bash"
python -c 'from ros_sugar import Launcher; from intera_core_msgs.msg import JointCommand; print("Imports OK")'
```

After connecting and launching the bridge using ROBOT_SETUP.md, run
`python sugarcoat_sawyer.py` in another terminal using the same environment and
ROS_DOMAIN_ID. The example subscribes to joint states and publishes no commands.

## System Humble versus RoboStack

This `robostack_humble_py312` artifact requires RoboStack Humble. It does not work
as an overlay for `/opt/ros/humble`. System Humble on Ubuntu 22.04 requires the
separate `humble_py310` build linked to system Python 3.10 and Boost 1.74.
The bridge project supports both builds, but they are not interchangeable.
Only the RoboStack 0.1.0 artifact is included in this release.
Do not source system ROS setup files in this Conda environment.

The package bundles private ROS 1 C++ client libraries; a full ROS 1 installation
on the laptop is unnecessary. Sawyer supplies the ROS 1 master and Intera nodes.
Software validation uses synthetic localhost data; hardware behavior has not
been validated by this release build.
