"""Read Sawyer joint telemetry with Sugarcoat 0.7.0; publishes no commands."""
from ros_sugar import Launcher
from ros_sugar.config import BaseComponentConfig, QoSConfig
from ros_sugar.core import BaseComponent
from ros_sugar.io import Topic
from ros_sugar.io.callbacks import GenericCallback
from ros_sugar.io.supported_types import SupportedType, add_additional_datatypes
from rclpy.qos import ReliabilityPolicy
from rosidl_runtime_py.convert import message_to_ordereddict
from sensor_msgs.msg import JointState
from intera_core_msgs.msg import JointCommand


class RosMessageCallback(GenericCallback):
    """Keep the complete ROS message, including its names and timestamp."""

    def _get_output(self, **_):
        return self.msg

    def _get_ui_content(self, **_):
        return message_to_ordereddict(self.msg) if self.msg is not None else {}


class SawyerJointState(SupportedType):
    _ros_type = JointState
    callback = RosMessageCallback

    @classmethod
    def convert(cls, output, **_):
        if not isinstance(output, cls._ros_type):
            raise TypeError(f'Expected {cls._ros_type.__name__}')
        return output


class SawyerJointCommand(SawyerJointState):
    _ros_type = JointCommand


add_additional_datatypes([SawyerJointState, SawyerJointCommand])


class SawyerTelemetry(BaseComponent):
    def __init__(self, topic_name='/robot/joint_states'):
        self.last_state = None
        super().__init__(
            component_name='sawyer_telemetry',
            inputs=[Topic(name=topic_name, msg_type=SawyerJointState,
                          qos_profile=QoSConfig(queue_size=5,
                              reliability=ReliabilityPolicy.BEST_EFFORT))],
            outputs=[],
            config=BaseComponentConfig(loop_rate=2.0),
        )

    def _execution_step(self):
        state = self.callbacks[self.in_topics[0].name].get_output()
        if state is not None:
            self.last_state = state
            self.get_logger().info(str(dict(zip(state.name, state.position))))


if __name__ == '__main__':
    launcher = Launcher()
    launcher.add_pkg(components=[SawyerTelemetry()], multiprocessing=False)
    launcher.bringup()
